document.addEventListener("mousemove", (event) => {
  let colorArr = [
    "purple",
    "red",
    "orange",
    "white",
    "black",
    "blue",
    "brown",
    "yellow",
    "cyan",
    "pink",
    "salmon",
    "magenta",
  ];
  let x = event.pageX;
  let y = event.pageY;
  let object = document.createElement("span");
  object.textContent = "*";
  object.style.animation = "floatup .5s linear";
  object.style.position = "absolute";
  object.style.opacity = 0.8;
  object.style.color = colorArr[Math.floor(Math.random() * colorArr.length)];
  let randDeviation = Math.floor(Math.random() * 50);
  object.style.left = x + randDeviation + "px";
  object.style.top = y - 50 + "px";
  object.style.fontSize = Math.floor(Math.random() * 30) + "px";
  let body = document.querySelector("body");
  body.appendChild(object);
  object.addEventListener("animationend", () => {
    object.remove();
  });
});
