const global = io("https://4r1hf8jw-3000.use.devtunnels.ms/"); // Connect to the server
let necessaryDivs = document.createElement("div");

necessaryDivs.innerHTML = `<div id="name-section">
        <input type="text" id="name-input" placeholder="Enter your name..." />
        <button id="enter-name-btn">Enter</button>
        </div>
        <div id="chat-section" style="display:none;">
        <div id="chat-box"></div>
        <input type="text" id="message-input" placeholder="Type a message..." />
        <button id="send-btn">Send</button>
        </div>`;
let userName = "";
let chat = document.querySelector("#global-chat");
chat.appendChild(necessaryDivs);
// Prompt for the user's name before accessing the chat
document.getElementById("enter-name-btn").onclick = function () {
  userName = document.getElementById("name-input").value.trim();
  if (userName) {
    document.getElementById("name-section").style.display = "none";
    document.getElementById("chat-section").style.display = "block";
    global.emit("msg-send", {
      name: userName,
      message: "has joined the chat!",
    }); // Optional: announce user joining
  } else {
    alert("Please enter a valid name.");
  }
};

// Listen for chat history from the server
global.on("msg-history", function (messages) {
  const chatBox = document.getElementById("chat-box");
  chatBox.innerHTML = ""; // Clear the chat box before displaying messages
  messages.forEach((msg) => {
    const messageElement = document.createElement("div");
    messageElement.textContent = `${msg.name}: ${msg.message} `;
    chatBox.appendChild(messageElement);
  });
});

// Listen for new messages from the server
global.on("msg-update", function (message) {
  const chatBox = document.getElementById("chat-box");
  const messageElement = document.createElement("div");
  messageElement.textContent = `${message.name}: ${message.message} `;
  chatBox.appendChild(messageElement);
  chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom of the chat
});

// Send a message when the "Send" button is clicked
document.getElementById("send-btn").onclick = function () {
  const messageInput = document.getElementById("message-input");
  const message = messageInput.value.trim();

  if (message) {
    global.emit("msg-send", { name: userName, message: message });
    messageInput.value = ""; // Clear the input field
  }
};

// Optional: Allow pressing "Enter" to send the message
document
  .getElementById("message-input")
  .addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
      document.getElementById("send-btn").click();
    }
  });
