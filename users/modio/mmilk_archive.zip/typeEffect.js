let typewriter = document.querySelector('.typewriter');
let text = "idk what to put here";
let speed = 100;
let i = 0;
function typeWriter(){
    let currLetter = document.createElement('span');
    
    
    
    if (i < text.length){
        currLetter.innerText = text.charAt(i);
        typewriter.append(currLetter);
        i++;
        setTimeout(typeWriter,speed);
    }
    else if(i == text.length){
        let cursor = document.querySelector('.cursor');
        cursor.setAttribute('id','cursor');
        
        
    }
}
typeWriter();