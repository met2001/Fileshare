discord_ID = "182963955130564608";
const API_URL = `https://api.lanyard.rest/v1/users/${discord_ID}`;

const getDiscordStats = async() =>{
    
    const response = await fetch(API_URL);
    const json = await response.json();
    console.log('Connected: ' + json.success);

    let discImg = document.querySelector('#discordImg');
    discImg.setAttribute('src',`https://api.lanyard.rest/${discord_ID}.png`);

    
    
    try{
        let discActivity = document.querySelector('.doing');
        discActivity.style.color = 'grey';
        discActivity.innerText = "On " + json.data['activities'][0]['name'];
    }
    catch{
        let discActivity = document.querySelector('.doing');
        discActivity.style.color = 'grey';
        discActivity.innerText = "Doing Nothing";
    }

    if(json.success == true){
        if(json.data['discord_status'] == 'online'){
            let status = document.querySelector("#status");
            status.textContent = "Online";
            status.style.color = 'green';
            
            console.log("online");
            let onlineStatus = document.querySelector('.onlineStatus');
            onlineStatus.style.color = 'green';
            onlineStatus.innerText = 'online';
            
            
        }
        else if(json.data['discord_status'] == 'dnd'){
            let status = document.querySelector("#status");
            status.textContent = "Do not Disturb";
            status.style.color = 'red';
            
            console.log("dnd");
            let onlineStatus = document.querySelector('.onlineStatus');
            onlineStatus.style.color = 'red';
            onlineStatus.innerText = 'do not disturb';

        }
        else if(json.data['discord_status'] == 'idle'){
            let status = document.querySelector("#status");
            status.textContent = "Idle";
            status.style.color = 'yellow';
            
            console.log("idle");
            let onlineStatus = document.querySelector('.onlineStatus');
            onlineStatus.style.color = 'yellow';
            onlineStatus.innerText = 'idle';

        }
        else{
            let status = document.querySelector("#status");
            status.textContent = "Offline";
            status.style.color = 'grey';
            
            console.log("offline");
            let onlineStatus = document.querySelector('.onlineStatus');
            onlineStatus.style.color = 'black';
            onlineStatus.innerText = 'offline';

        }

        let discordStatus = document.querySelector('.discordStatus');
        
        discordStatus.innerText = json.data['discord_user']['username'];
        
    }
}

getDiscordStats();
setInterval(() => { getDiscordStats(); }, 1000);
