const BLOG_API = `https://4r1hf8jw-5000.use.devtunnels.ms/API/POSTS`;

const getBlogPosts = async () => {
    const response = await fetch(BLOG_API);
    const json = await response.json();

    let POSTS = json;
    let timeline = document.querySelector(".posts");

    // Clear any existing posts before adding new ones
    timeline.innerHTML = "";

    POSTS.forEach(post => {
        // Create a new blog post container for each post
        let blog_post = document.createElement("div");
        blog_post.setAttribute("class", "post");

        // Set the inner HTML for each post
        blog_post.innerHTML = `
            <div class="content">
                
                <p>${post.content}</p>
            </div>
            <div style="text-align: center;">
                <img style="border-radius: 50%;" width="100" src="./images/mrbabycropped.jpg">
                <p style="font-size: .8rem">${post.timestamp}</p>
            </div>
        `;
        
        // Append each new blog post to the timeline
        timeline.appendChild(blog_post);
    });
}

getBlogPosts();
