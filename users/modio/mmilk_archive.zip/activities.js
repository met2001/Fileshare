const d_ID = "182963955130564608";
const ACTIVITY_URL = `https://api.lanyard.rest/v1/users/${d_ID}`;

const getActivities = async() =>{
    
    const response = await fetch(ACTIVITY_URL);
    const json = await response.json();
    console.log('Connected: ' + json.success);
    let section = document.querySelector("#sec2");
    let activityImgBox = document.querySelector('.activityImg');
    let activityImg = document.querySelector('#songImg');
    let songName = document.querySelector('#songName');
    let artistName = document.querySelector('#artistName');
    let albumName = document.querySelector('#albumName');
    let curSong = document.querySelector('#currentListening');
    let body = document.querySelector('body');
    body.setAttribute('background-image','linear-gradient(45deg, #5e3769, #e5cdf3)');
    let artist;
    let song;
    let musicArt;
    let album;
    if(json.success == true){
        let spotify = json.data['spotify'];
        if(spotify != null){
            songImg.setAttribute('width','180px')
            artistName.style.display = 'block';
            albumName.style.display = 'block';
            section.style.display = 'block';
            let activities = json.data.activities;
            activities.forEach(activity => {
                let actName = activity.name;
                console.log(actName);
                
            });
            musicArt = json.data.spotify.album_art_url;
            console.log(musicArt);
            artist = json.data.spotify.artist;
            song = json.data.spotify.song;
            album = json.data.spotify.album;
            console.log(song + " by: " + artist + " album: " + album);
            songImg.setAttribute('src',musicArt);
            songName.innerHTML = `<mark>${song}</mark>`;
            artistName.innerText = artist;
            albumName.innerText = album;
            curSong.innerText = `Listening to ${json.data.activities[0].details}`;
            let body = document.querySelector('body');
            body.setAttribute('style',`background-image: url(${json.data.spotify.album_art_url}); position: sticky`);
            
        }
        else if(spotify == null){
            curSong.innerText = "offline";
            songImg.setAttribute('src','./album.webp');
            songImg.setAttribute('width','80px')
            artistName.style.display = 'none';
            albumName.style.display = 'none';
        }

        let activities = json.data.activities;
        activities.forEach(activity =>{
            let actName = activity.name;

        })
        
    }
}

getActivities();
setInterval(() => { getActivities(); }, 1000);