const SOCKET_URL = "https://4r1hf8jw-5000.use.devtunnels.ms/";
const socket = io(SOCKET_URL);

// Styling for the cursor elements
const style = document.createElement("style");
style.innerHTML = `
    .pointer {
        width: 20px;
        height: 20px;
        position: absolute;
        opacity: 50%;
        
        pointer-events: none; /* Prevent cursor from interfering with mouse events */
    }
`;
document.head.appendChild(style);

// Emit cursor position to the server on mousemove
document.addEventListener("mousemove", (event) => {
  socket.emit("cursor-move", {
    x: event.pageX,
    y: event.pageY,
  });
});

// Receive cursor updates from the server
socket.on("cursor-update", (data) => {
  let numUsers = document.querySelectorAll(".pointer").length + 1;
  console.log(numUsers);
  let current_users = (document.querySelector("#current-users").innerHTML =
    `<mark>current users</mark>: ${numUsers}`);
  if (data.id === socket.id) {
    return;
  }
  let userCursor = document.getElementById(`cursor-${data.id}`);
  if (!userCursor) {
    // Create a new cursor element for this user
    userCursor = document.createElement("div");
    userCursor.id = `cursor-${data.id}`;
    userCursor.classList.add("pointer");
    userCursor.style.backgroundImage = 'url("./images/cursor.png")'; // Different color for other users
    document.body.appendChild(userCursor);
  }
  // Update the cursor's position
  userCursor.style.left = `${data.x}px`;
  userCursor.style.top = `${data.y}px`;
  console.log(data.x);
});

// Remove cursor when a user disconnects
socket.on("cursor-remove", (data) => {
  const userCursor = document.getElementById(`cursor-${data.id}`);
  if (userCursor) {
    userCursor.remove();
  }
});
