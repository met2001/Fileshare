document.addEventListener('mousemove', function(event){
    let target = document.querySelector('.tilt');
    let x = event.clientX - target.offsetLeft - target.offsetWidth / 2;
    let y = event.clientY - target.offsetTop - target.offsetHeight / 2;
    const maxTilt = 4;
    let rotateX = (y / target.offsetHeight) * maxTilt;
    let rotateY = (x / target.offsetWidth) * maxTilt;
    target.style.transform = `perspective(1000px) rotateX(${-rotateX}deg) rotateY(${rotateY}deg)`;
    
})