
const BASE_URL = `https://lastfm-last-played.biancarosa.com.br/mm1lk/latest-song`;

const getTrack = async () => {
    const request = await fetch(BASE_URL);
    const json = await request.json();
    let status

    let isPlaying = json.track['@attr']?.nowplaying || false;

    if(!isPlaying) {
        
        
        
        document.getElementById("listening").innerHTML = `
    <h3>Offline</h3>   
    <img class="notlistening" src="${json.track.image[2]['#text']}">
    <div id="trackInfo">
    <h3 id="trackName">${json.track.name}</h3>
    <p id="artistName">${json.track.artist['#text']}</p>
    </div>
    `

 
        return;
    } else {
        
        document.getElementById("listening").innerHTML = `
    <h3>Currently Listening:</h3>
    <img src="${json.track.image[2]['#text']}">
    <div id="trackInfo">
    <h3 id="trackName">${json.track.name}</h3>
    <p id="artistName">${json.track.artist['#text']}</p>
    </div>
    `
    let online = document.querySelector("#listeningNow");
    online.style.color = "Green";
    let background = document.querySelector("body");
    background.style.backgroundImage(json.track.image[3]);
    }
    let background = document.querySelector("body");
    background.style.backgroundImage(json.track.image[3]['text']);
    // Values:
    // COVER IMAGE: json.track.image[1]['#text']
    // TITLE: json.track.name
    // ARTIST: json.track.artist['#text']

    
};

getTrack();
setInterval(() => { getTrack(); }, 100);
let letArr = ["c","o","m","p","u","t","e","r"," ","s","c","i","e","n","c","e"," ","s","t","u","d","e","n","t"];
let colorArr = ["black","green"];
let pElm = document.querySelector('.bouncy');

// Create span elements for each letter and add them to pElm
let letterElems = letArr.map(letter => {
    let newElm = document.createElement("span");
    newElm.className = "bouncy";
    newElm.textContent = letter;
    newElm.style.display = "inline";
    newElm.style.animation = "none"; // Start without animation
    pElm.appendChild(newElm);
    return newElm;
});

// Initialize index for looping through letters
let currentIndex = 0;

// Function to update colors and animate one letter at a time
setInterval(() => {
    // Update color for each letter randomly
    letterElems.forEach(elem => {
        elem.style.color = colorArr[Math.floor(Math.random() * colorArr.length)];
    });

    // Reset the animation for all letters
    letterElems.forEach(elem => elem.style.animation = "none");

    // Apply bounce animation to the current letter
    letterElems[currentIndex].style.animation = "bounce 1s infinite";

    // Move to the next letter (wrap back to start if at the end)
    currentIndex = (currentIndex + 1) % letterElems.length;
}, 50); 

function createSnowflake() {
    if(document.querySelectorAll(".snowflake").length <= 20){
        let snowflake = document.createElement("span");
    snowflake.classList.add("snowflake");
    snowflake.textContent = "*"; 
    
    let size = Math.random() * 1.5 + 0.5; 
    snowflake.style.fontSize = `${size}em`;
    let startLeft = Math.random() * 100; 
    snowflake.style.left = `${startLeft}vw`;
   let fallDuration = Math.random() * 3 + 7; 
    snowflake.style.animationDuration = `${fallDuration}s`;

    document.body.appendChild(snowflake);
    snowflake.addEventListener("animationend", () => {
        snowflake.remove();
    });
    }
    else{
        console.log("Max snowflakes");
    }
    
    console.log(document.querySelectorAll(".snowflake").length);
  
    
}


setInterval(createSnowflake, 500);

